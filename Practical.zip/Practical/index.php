<?php
 include('config.php');
 // Fetch Data List 
  $res=mysqli_query($con,"select * from user");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.css" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"
        integrity="sha512-3gJwYpMe3QewGELv8k/BX9vcqhryRdzRMxVfq6ngyWXwo03GFEzjsUm8Q7RZcHPHksttq7/GFoxjCVUjkjvPdw=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <title>Php | Practical</title>
</head>
<body>

    <div class="text-center mt-2">
        <h3>User Registration</h3>
    </div>
    <div class="container card mt-2">
        <form name="user_register" id="form" method="post">
            <div class="row">
                <div class="form-group col-lg-3 p-2">
                    <label for="exampleInputEmail1">First Name</label>
                    <input type="text" class="form-control" name="first_name" id="first_name_id"
                        placeholder="First Name">
                </div>
                <div class="form-group col-lg-3 p-2">
                    <label for="exampleInputPassword1">Last Name</label>
                    <input type="text" class="form-control" name="last_name" id="last_name_id" placeholder="Last Name">
                </div>
                <div class="form-group col-lg-3 p-2">
                    <label for="exampleInputPassword1">Email</label>
                    <input type="email" class="form-control" name="email" id="email_id" placeholder="Email">
                </div>
                <div class="form-group col-lg-3 p-2">
                    <label for="exampleInputPassword1">Number</label>
                    <input type="text" class="form-control" name="mobile_number" id="number_id" placeholder="Number">
                </div>
            </div>
            <button  type="button" class="btn btn-primary" name="save" onclick="saveUser();">Submit</button>
            <button  type="button" class="btn btn-danger" name="delete" onclick="deleteUser();">Delete</button>
            <!-- Table Area Start -->
            <br><br>
            <table id="usertable" class="table" style="width:100%">
                <thead>
                    <tr>
                        <th>select</th>
                        <th>SL.No</th>
                        <th>FirstName</th>
                        <th>LastName</th>
                        <th>Email</th>
                        <th>Number</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                       $index=0;
                       while($row=mysqli_fetch_assoc($res)){
                       $index++;
                    ?>
                      <tr>
                      <td><input type="checkbox" id="checkBox<?php echo $index ?>" name="user[]" value="<?php echo $row['id']?>"></td>
                      <td><?php echo $index ?></td>
                      <td>
                        <?php echo $row['first_name']?>
                        <input type="text" id="first_name<?php echo $index ?>" value="<?php echo $row['first_name']?>" class="d-none">
                     </td>
                      <td>
                        <?php echo $row['last_name']?>
                        <input type="text" id="last_name<?php echo $index ?>" value="<?php echo $row['last_name']?>" class="d-none">
                      </td>
                      <td>
                        <?php echo $row['email']?>
                        <input type="email" id="email<?php echo $index ?>" value="<?php echo $row['email']?>" class="d-none">
                      </td>
                      <td>
                        <?php echo $row['mobile_number']?>
                        <input type="text" id="mobile_number<?php echo $index ?>" value="<?php echo $row['mobile_number']?>"class="d-none">
                     </td>
                      <td>
                      <button  type="button" class="btn btn-primary" onclick="enableEdit('<?php echo $index?>')">Edit</button>
                      <button  type="button" id="enableSave<?php echo $index?>" class="btn btn-success" onclick="UpdateData('<?php echo $index?>','<?php echo $row['id']?>')" disabled>Save</button>
                      </td>
                       </tr>  
                    <?php } ?>
                    
                </tbody>
            </table>
    </div><br><br>
    </form>
    </div>
</body>
<script>
    $(document).ready(function () {
        $('#usertable').DataTable();
    });
    function enableEdit(id){
        $("#first_name"+id).removeClass("d-none");
        $("#last_name"+id).removeClass("d-none");
        $("#email"+id).removeClass("d-none");
        $("#mobile_number"+id).removeClass("d-none");
        $("#enableSave"+id).removeAttr('disabled');
    }
    // Save Data
    function saveUser(){
      var firstName=$("#first_name_id").val();
      var lastName=$("#last_name_id").val();
      var email=$("#email_id").val();
      var number=$("#number_id").val();
      $.ajax({
        url:'operation.php',
        method:'post',
        data:'type=save'+'&firstName='+firstName+'&lastName='+lastName+'&email='+email+'&number='+number,
        success:function(result){
            if(result=="true"){
                Swal.fire('Success!','User Register Succesfully!','success');
                setTimeout(() => {window.location.href = "index.php";},2000);
               
            }
            else{
                Swal.fire('OOps!','Something went wrong!','error');
                setTimeout(() => {window.location.href = "index.php";},2000);
            }
        }
      });
    }

    //Edit Data
    function UpdateData(index,id){
      var firstName=$("#first_name"+index).val();
      var lastName=$("#last_name"+index).val();
      var email=$("#email"+index).val();
      var number=$("#mobile_number"+index).val();
      $.ajax({
        url:'operation.php',
        method:'post',
        data:'type=update'+'&id='+id+'&firstName='+firstName+'&lastName='+lastName+'&email='+email+'&number='+number,
        success:function(result){
            if(result=="true"){
                Swal.fire('Success!','User Update Succesfully!','success');
                setTimeout(() => {window.location.href = "index.php";},2000);
               
            }
            else{
                Swal.fire('OOps!','Something went wrong!','error');
                setTimeout(() => {window.location.href = "index.php";},2000);
            }
        }
      });

    }

    // Delete User
    function deleteUser(){
        var val = [];
        $(':checkbox:checked').each(function(i){
          val[i] = $(this).val();
        });
        $.ajax({
        url:'operation.php',
        method:'post',
        data:'type=delete'+'&id='+val,
        success:function(result){
            console.log(result);
            if(result=="true"){
                Swal.fire('Success!','User delete Succesfully!','success');
                setTimeout(() => {window.location.href = "index.php";},2000);
               
            }
            else{
                Swal.fire('OOps!','Something went wrong!','error');
                setTimeout(() => {window.location.href = "index.php";},2000);
            }
        }
      });
    }
</script>
</html>

