<?php
 include('config.php');
 $type=$_POST['type'];

 if($type=='save'){
  $firts_name=$_POST['firstName'];
  $lastName=$_POST['lastName'];
  $email=$_POST['email'];
  $number=$_POST['number'];

  $sql=mysqli_query($con,"INSERT INTO `user`(`first_name`, `last_name`, `email`, `mobile_number`) 
  VALUES ('$firts_name','$lastName','$email','$number') ");
  if($sql){ echo "true"; }
 }

 else if ($type=='update'){
  $firts_name=$_POST['firstName'];
  $lastName=$_POST['lastName'];
  $email=$_POST['email'];
  $number=$_POST['number'];
  $id=$_POST['id'];
  
  $sql=mysqli_query($con,"UPDATE `user` SET `first_name`='$firts_name',`last_name`='$lastName',`email`='$email',`mobile_number`='$number' WHERE id='$id' ");
  if($sql){ echo "true"; }
  
} 

else if($type=='delete'){
  $val=$_POST['id'];
  $sql=mysqli_query($con,"DELETE FROM `user` WHERE id in($val) ");
  if($sql){ echo "true"; }
}

?>